/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { PackagesSection } from './components/PackagesSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { EnquiryModal } from './components/EnquiryModal';
import { PackageItem } from './data/siteData';

export default function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalPackageId, setModalPackageId] = useState<string | undefined>(undefined);
  const [preselectedPackage, setPreselectedPackage] = useState<string | undefined>(undefined);
  const [preselectedService, setPreselectedService] = useState<string | undefined>(undefined);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenEnquiryModal = (pkgId?: string) => {
    setModalPackageId(pkgId);
    setIsModalOpen(true);
  };

  const handleGetStarted = () => {
    scrollToSection('packages');
  };

  const handleContactClick = () => {
    scrollToSection('contact');
  };

  const handleSelectQuickService = (serviceId: string) => {
    scrollToSection('services');
  };

  const handleAboutLearnMore = () => {
    scrollToSection('services');
  };

  const handlePackageSelect = (pkg: PackageItem) => {
    setPreselectedPackage(pkg.name);
    setPreselectedService(undefined);
    scrollToSection('contact');
  };

  const handleEnquireService = (serviceName: string) => {
    setPreselectedService(serviceName);
    setPreselectedPackage(undefined);
    scrollToSection('contact');
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900 selection:bg-amber-100 selection:text-amber-900">
      {/* Fixed Navigation Bar */}
      <Navbar onOpenEnquiry={handleOpenEnquiryModal} />

      {/* Main Page Flow matching user design */}
      <main className="flex-1">
        {/* 1. Hero Section with Westminster Twilight Backdrop & Quick Service Strip */}
        <HeroSection
          onGetStarted={handleGetStarted}
          onContactClick={handleContactClick}
          onSelectQuickService={handleSelectQuickService}
        />

        {/* 2. About Us Section with Overlapping Visual Cards & 3 Highlights */}
        <AboutSection onLearnMore={handleAboutLearnMore} />

        {/* 3. Our Services Section with 8 Detailed Cards & Interactive Modal */}
        <ServicesSection onEnquireService={handleEnquireService} />

        {/* 4. Our Packages Section with 4 Tier Cards & Clear Pricing */}
        <PackagesSection onSelectPackage={handlePackageSelect} />

        {/* 5. How It Works Section with 6 Steps & Interactive Indicators */}
        <HowItWorksSection onStartJourney={() => scrollToSection('contact')} />

        {/* 6. What Our Customers Say / Testimonials with London Panorama */}
        <TestimonialsSection />

        {/* 7. FAQ Section with Interactive Accordions & "Your Questions Matter" card */}
        <FaqSection onContactClick={handleContactClick} />

        {/* 8. Contact & Lead Capture Form */}
        <ContactSection
          preselectedPackage={preselectedPackage}
          preselectedService={preselectedService}
        />
      </main>

      {/* Footer */}
      <Footer />

      {/* Direct Booking / Quick Enquiry Modal */}
      <EnquiryModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        initialPackageId={modalPackageId}
      />
    </div>
  );
}
