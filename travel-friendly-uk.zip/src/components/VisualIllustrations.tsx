export function ServiceVisualCard({
  type,
  title,
  alt = ''
}: {
  type: string;
  title?: string;
  alt?: string;
}) {
  switch (type) {
    case 'airport-pickup':
      return (
        <div className="relative w-full h-36 bg-gradient-to-b from-sky-200 via-sky-100 to-slate-200 rounded-lg overflow-hidden border border-slate-200/80 group-hover:scale-[1.01] transition-transform">
          {/* Runway & Sky */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-700 via-slate-600/40 to-transparent z-0" />
          {/* Sun Glow */}
          <div className="absolute top-2 right-8 w-14 h-14 rounded-full bg-amber-200/60 blur-md" />
          {/* Mountains/Hills horizon */}
          <svg className="absolute bottom-10 left-0 right-0 w-full h-12 text-slate-400/40" viewBox="0 0 400 60" preserveAspectRatio="none">
            <path d="M0 45 Q 60 20 120 40 T 260 30 T 400 45 L 400 60 L 0 60 Z" fill="currentColor" />
          </svg>
          {/* Airport Runway Tarmac */}
          <div className="absolute bottom-0 inset-x-0 h-11 bg-slate-800 flex items-center justify-center">
            {/* Runway centerline dashes */}
            <div className="w-full border-t border-dashed border-amber-400/80" />
            <div className="absolute left-4 w-3 h-1 bg-white/70" />
            <div className="absolute right-4 w-3 h-1 bg-white/70" />
          </div>
          {/* Airplane on approach / runway */}
          <div className="absolute inset-0 flex items-center justify-center -translate-y-1">
            <svg viewBox="0 0 160 80" className="w-40 h-20 drop-shadow-md text-white">
              {/* Jet fuselage */}
              <ellipse cx="80" cy="40" rx="36" ry="7" fill="#ffffff" stroke="#0f172a" strokeWidth="1" />
              {/* Cockpit */}
              <path d="M112 38 Q 116 39 114 41 L 108 41 Z" fill="#38bdf8" />
              {/* Main Wings */}
              <path d="M68 40 L 48 18 L 60 18 L 84 40 Z" fill="#e2e8f0" stroke="#0f172a" strokeWidth="0.8" />
              <path d="M68 42 L 50 64 L 62 64 L 84 42 Z" fill="#cbd5e1" stroke="#0f172a" strokeWidth="0.8" />
              {/* Tail Fin */}
              <path d="M46 38 L 36 22 L 44 22 L 56 38 Z" fill="#0284c7" />
              {/* Engines */}
              <rect x="65" y="47" width="10" height="4" rx="2" fill="#475569" />
              <rect x="65" y="29" width="10" height="4" rx="2" fill="#475569" />
            </svg>
          </div>
          {/* Subtle Label */}
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-semibold bg-white/80 text-sky-950 backdrop-blur-xs">
            Heathrow & Regional Transfers
          </div>
        </div>
      );

    case 'accommodation':
      return (
        <div className="relative w-full h-36 bg-gradient-to-br from-amber-50 via-orange-50 to-stone-200 rounded-lg overflow-hidden border border-slate-200/80">
          {/* Cozy Bedroom & Window Vector */}
          <div className="absolute inset-0 bg-stone-100 flex items-end justify-center">
            {/* Sunlight beam through window */}
            <div className="absolute top-0 right-6 w-24 h-full bg-gradient-to-b from-amber-200/40 via-amber-100/20 to-transparent transform -skew-x-12 pointer-events-none" />
            {/* Window frame */}
            <div className="absolute top-2 right-4 w-20 h-16 border-2 border-amber-800/20 bg-sky-100/60 rounded flex items-center justify-center">
              <div className="w-full h-[1px] bg-amber-800/20" />
              <div className="h-full w-[1px] bg-amber-800/20 absolute" />
            </div>
            {/* Wall headboard */}
            <div className="w-48 h-18 bg-amber-800/20 rounded-t-lg border-t-2 border-x-2 border-amber-900/30" />
            {/* Plush Bed & Pillows */}
            <div className="absolute bottom-0 inset-x-8 h-16 bg-white rounded-t-xl shadow-md border-t border-slate-200 flex flex-col items-center">
              {/* Bed throw runner */}
              <div className="w-full h-5 bg-teal-700/80 mt-auto rounded-b" />
              {/* Pillows */}
              <div className="absolute -top-3 flex gap-2">
                <div className="w-12 h-6 bg-slate-100 rounded-md border border-slate-300 shadow-xs transform -rotate-3" />
                <div className="w-12 h-6 bg-slate-100 rounded-md border border-slate-300 shadow-xs transform rotate-3" />
              </div>
            </div>
            {/* Bedside lamps */}
            <div className="absolute bottom-6 left-3 w-5 h-8 bg-amber-200/80 rounded-t-full border border-amber-300 shadow-sm" />
            <div className="absolute bottom-6 right-3 w-5 h-8 bg-amber-200/80 rounded-t-full border border-amber-300 shadow-sm" />
          </div>
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-semibold bg-white/85 text-stone-900 backdrop-blur-xs">
            Vetted Flatshares & Studios
          </div>
        </div>
      );

    case 'job-search':
      return (
        <div className="relative w-full h-36 bg-gradient-to-b from-slate-100 via-sky-50 to-slate-200 rounded-lg overflow-hidden border border-slate-200/80 flex items-center justify-center">
          {/* Modern Laptop on Work Desk */}
          <div className="relative flex flex-col items-center">
            {/* Laptop screen */}
            <div className="w-36 h-22 bg-slate-900 rounded-t-md p-1 border border-slate-700 shadow-lg flex flex-col">
              <div className="w-full bg-slate-800 px-1 py-0.5 rounded-t flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span className="text-[7px] text-slate-300 ml-1">UK Career Portal</span>
              </div>
              {/* Screen Content: CV & Job Match */}
              <div className="flex-1 bg-white p-1.5 rounded-b flex flex-col justify-between">
                <div className="flex items-center justify-between border-b pb-0.5">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 rounded-full bg-sky-500 flex items-center justify-center text-[7px] text-white font-bold">✓</div>
                    <span className="text-[8px] font-bold text-slate-800">Targeted UK CV</span>
                  </div>
                  <span className="text-[7px] px-1 bg-emerald-100 text-emerald-800 font-medium rounded">Match 95%</span>
                </div>
                <div className="space-y-0.5 py-0.5">
                  <div className="w-full h-1 bg-slate-200 rounded" />
                  <div className="w-4/5 h-1 bg-slate-200 rounded" />
                  <div className="w-3/5 h-1 bg-sky-200 rounded" />
                </div>
                <div className="flex justify-between items-center text-[7px] text-slate-500">
                  <span>Right-to-Work check</span>
                  <span className="text-sky-600 font-semibold">Ready</span>
                </div>
              </div>
            </div>
            {/* Laptop Base */}
            <div className="w-44 h-2.5 bg-slate-400 rounded-b-md shadow-md border-t border-slate-300 flex justify-center">
              <div className="w-8 h-1 bg-slate-600 rounded-b" />
            </div>
          </div>
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-semibold bg-white/85 text-slate-900 backdrop-blur-xs">
            CV, LinkedIn & Interview Prep
          </div>
        </div>
      );

    case 'ni-guidance':
      return (
        <div className="relative w-full h-36 bg-gradient-to-br from-blue-900 via-indigo-900 to-sky-950 rounded-lg overflow-hidden border border-slate-200/80 p-2 flex items-center justify-center">
          {/* UK Flag background subtle weave */}
          <div className="absolute inset-0 opacity-25">
            <svg viewBox="0 0 60 30" className="w-full h-full object-cover">
              <clipPath id="s">
                <path d="M0,0 v30 h60 v-30 z"/>
              </clipPath>
              <clipPath id="t">
                <path d="M30,15 h30 v15 z v15 h-30 z h-30 v-15 z v-15 h30 z"/>
              </clipPath>
              <g clipPath="url(#s)">
                <path d="M0,0 v30 h60 v-30 z" fill="#012169"/>
                <path d="M0,0 L60,30 M60,0 L0,30" stroke="#fff" strokeWidth="6"/>
                <path d="M0,0 L60,30 M60,0 L0,30" clipPath="url(#t)" stroke="#C8102E" strokeWidth="4"/>
                <path d="M30,0 v30 M0,15 h60" stroke="#fff" strokeWidth="10"/>
                <path d="M30,0 v30 M0,15 h60" stroke="#C8102E" strokeWidth="6"/>
              </g>
            </svg>
          </div>
          {/* Government NI Card */}
          <div className="relative z-10 w-44 bg-white/95 backdrop-blur-md rounded-md p-2.5 shadow-xl border border-white/40">
            <div className="flex items-center justify-between border-b pb-1 mb-1.5">
              <span className="text-[8px] font-extrabold tracking-widest text-blue-900">HM REVENUE & CUSTOMS</span>
              <span className="text-[8px] bg-red-600 text-white font-black px-1 rounded">UK</span>
            </div>
            <div className="text-[10px] font-mono font-bold text-slate-800 tracking-wider">
              QQ 12 34 56 C
            </div>
            <div className="text-[8px] text-slate-600 mt-1 flex justify-between items-center">
              <span>National Insurance Number</span>
              <span className="text-emerald-700 font-bold">Approved</span>
            </div>
          </div>
          <div className="absolute top-2 left-2 z-20 px-2 py-0.5 rounded text-[10px] font-semibold bg-white/90 text-blue-950 backdrop-blur-xs">
            HMRC Application Support
          </div>
        </div>
      );

    case 'sim-setup':
      return (
        <div className="relative w-full h-36 bg-gradient-to-br from-indigo-50 via-slate-100 to-sky-100 rounded-lg overflow-hidden border border-slate-200/80 flex items-center justify-center">
          {/* Hand Holding Smartphone */}
          <div className="relative flex items-center justify-center">
            {/* Phone casing */}
            <div className="w-22 h-30 bg-slate-900 rounded-xl p-1 shadow-xl border border-slate-700 flex flex-col">
              {/* Dynamic island */}
              <div className="w-6 h-1.5 bg-black rounded-full mx-auto my-0.5" />
              {/* Screen */}
              <div className="flex-1 bg-gradient-to-b from-sky-500 to-indigo-600 rounded-lg p-1.5 text-white flex flex-col justify-between">
                <div className="flex items-center justify-between text-[7px]">
                  <span>5G UK Network</span>
                  <span>100%</span>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded p-1 text-center">
                  <div className="text-[11px] font-bold">Unlimited</div>
                  <div className="text-[6.5px]">UK Data + Minutes</div>
                </div>
                <div className="text-[7px] text-center font-medium bg-emerald-400 text-emerald-950 rounded py-0.5">
                  eSIM Activated
                </div>
              </div>
            </div>
            {/* Micro SIM Card Floating Graphic */}
            <div className="absolute -right-4 -bottom-1 w-10 h-7 bg-amber-400 rounded-sm border border-amber-600 shadow-md p-0.5 flex flex-col justify-between transform rotate-12">
              <div className="w-2.5 h-2 bg-amber-500 rounded-tl" />
              <div className="grid grid-cols-2 gap-0.5">
                <div className="h-1 bg-amber-600" />
                <div className="h-1 bg-amber-600" />
              </div>
              <span className="text-[5px] font-bold text-amber-950">SIM</span>
            </div>
          </div>
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-semibold bg-white/85 text-slate-900 backdrop-blur-xs">
            eSIM / Physical SIM on Arrival
          </div>
        </div>
      );

    case 'transport':
      return (
        <div className="relative w-full h-36 bg-gradient-to-b from-sky-100 via-sky-50 to-slate-200 rounded-lg overflow-hidden border border-slate-200/80">
          {/* Iconic London Red Bus & Street Vector */}
          <div className="absolute inset-0 flex items-end justify-center pb-2">
            {/* London Street backdrop */}
            <div className="absolute bottom-7 inset-x-0 h-1 bg-slate-400" />
            {/* Classic Red Double Decker Bus */}
            <div className="relative w-40 h-24 bg-red-600 rounded-lg shadow-lg border-2 border-red-700 flex flex-col p-1">
              {/* Upper deck windows */}
              <div className="flex gap-1 h-7 bg-red-700/40 p-0.5 rounded">
                <div className="flex-1 bg-sky-200/90 rounded-xs border border-red-900/40" />
                <div className="flex-1 bg-sky-200/90 rounded-xs border border-red-900/40" />
                <div className="flex-1 bg-sky-200/90 rounded-xs border border-red-900/40" />
                <div className="flex-1 bg-sky-200/90 rounded-xs border border-red-900/40" />
              </div>
              {/* Destination board */}
              <div className="w-24 mx-auto my-0.5 bg-black text-amber-400 text-[6.5px] font-bold tracking-wider text-center py-0.5 rounded">
                15 TRAFALGAR SQ
              </div>
              {/* Lower deck windows & door */}
              <div className="flex gap-1 h-7 bg-red-700/40 p-0.5 rounded items-center">
                <div className="w-4 h-full bg-slate-900/40 rounded-xs" />
                <div className="flex-1 bg-sky-200/90 rounded-xs h-full border border-red-900/40" />
                <div className="flex-1 bg-sky-200/90 rounded-xs h-full border border-red-900/40" />
              </div>
              {/* Wheels */}
              <div className="absolute -bottom-2 left-6 w-5 h-5 rounded-full bg-slate-900 border-2 border-slate-400 flex items-center justify-center">
                <div className="w-1.5 h-1.5 bg-white rounded-full" />
              </div>
              <div className="absolute -bottom-2 right-6 w-5 h-5 rounded-full bg-slate-900 border-2 border-slate-400 flex items-center justify-center">
                <div className="w-1.5 h-1.5 bg-white rounded-full" />
              </div>
            </div>
            {/* London Tube Roundel floating */}
            <div className="absolute top-2 right-2 w-7 h-7 flex items-center justify-center">
              <div className="w-6 h-6 rounded-full border-2 border-red-600 bg-transparent flex items-center justify-center">
                <div className="w-7 h-2 bg-blue-700 rounded-xs flex items-center justify-center">
                  <span className="text-[4px] text-white font-bold">UNDERGROUND</span>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-semibold bg-white/85 text-slate-900 backdrop-blur-xs">
            Oyster, Railcard & Underground
          </div>
        </div>
      );

    case 'banking':
      return (
        <div className="relative w-full h-36 bg-gradient-to-b from-sky-900 via-sky-800 to-slate-900 rounded-lg overflow-hidden border border-slate-200/80 p-2 flex items-center justify-center">
          {/* UK Bank Branch storefront & Barclays style facade */}
          <div className="relative w-48 bg-sky-950 rounded-md border border-sky-600 shadow-xl p-2 flex flex-col items-center">
            {/* Bank Header Signboard */}
            <div className="w-full bg-sky-500 py-1 px-2 rounded flex items-center justify-between text-white shadow-sm">
              <div className="flex items-center gap-1">
                {/* Eagle/Globe bank mark */}
                <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current">
                  <path d="M12 2L2 7V9H22V7L12 2ZM4 11V18H7V11H4ZM10 11V18H14V11H10ZM17 11V18H20V11H17ZM2 20V22H22V20H2Z" />
                </svg>
                <span className="text-[10px] font-black tracking-widest uppercase">BARCLAYS</span>
              </div>
              <span className="text-[7px] bg-white/20 px-1 py-0.5 rounded">UK Branch</span>
            </div>
            {/* Pillars and glass doors */}
            <div className="w-full flex justify-between gap-1.5 mt-1.5 px-2">
              <div className="w-3 h-10 bg-slate-200 rounded-xs border border-slate-300" />
              <div className="flex-1 bg-sky-300/30 rounded border border-sky-400/50 flex flex-col items-center justify-center text-center p-1">
                <div className="text-[8px] font-bold text-sky-200">Current Account</div>
                <div className="text-[6.5px] text-white">Monzo · Revolut · Lloyds</div>
              </div>
              <div className="w-3 h-10 bg-slate-200 rounded-xs border border-slate-300" />
            </div>
          </div>
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-semibold bg-white/85 text-slate-900 backdrop-blur-xs">
            Digital & High-Street Accounts
          </div>
        </div>
      );

    case 'orientation':
    default:
      return (
        <div className="relative w-full h-36 bg-gradient-to-b from-amber-100 via-sky-100 to-amber-50 rounded-lg overflow-hidden border border-slate-200/80">
          {/* Big Ben & London Skyline Vector */}
          <div className="absolute inset-0 flex items-end justify-center">
            <svg viewBox="0 0 240 100" className="w-full h-24 text-slate-700" preserveAspectRatio="none">
              {/* Palace of Westminster silhouettes */}
              <path d="M10 100 L10 55 L35 55 L35 100 Z" fill="#64748b" />
              <path d="M40 100 L40 45 L65 45 L65 100 Z" fill="#475569" />
              {/* Clock Tower Big Ben */}
              <path d="M75 100 L75 35 L70 35 L78 15 L86 15 L94 35 L89 35 L89 100 Z" fill="#334155" />
              {/* Clock face */}
              <circle cx="82" cy="38" r="4" fill="#fef08a" />
              <path d="M95 100 L95 50 L140 50 L140 100 Z" fill="#64748b" />
              <path d="M145 100 L145 60 L180 60 L180 100 Z" fill="#475569" />
              <path d="M185 100 L185 45 L220 45 L220 100 Z" fill="#334155" />
            </svg>
            {/* River Thames Reflection */}
            <div className="absolute bottom-0 inset-x-0 h-4 bg-sky-800/30 backdrop-blur-xs border-t border-sky-600/40" />
          </div>
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-semibold bg-white/85 text-slate-900 backdrop-blur-xs">
            Neighbourhood & GP Registration
          </div>
        </div>
      );
  }
}

export function PackageVisualCard({ theme }: { theme: 'sky' | 'emerald' | 'indigo' | 'navy' }) {
  const gradientMap = {
    sky: 'from-sky-500 via-sky-600 to-blue-700',
    emerald: 'from-emerald-500 via-teal-600 to-teal-800',
    indigo: 'from-indigo-500 via-indigo-600 to-purple-800',
    navy: 'from-slate-800 via-blue-950 to-slate-950',
  };

  const iconScene = {
    sky: (
      <div className="flex items-center gap-2">
        <svg viewBox="0 0 100 50" className="w-20 h-10 text-white fill-current drop-shadow">
          <path d="M20 25 L40 10 L50 10 L45 25 L75 25 L85 18 L92 18 L88 25 L98 25 L95 30 L85 30 L45 30 L35 45 L25 45 L32 30 L10 30 Z" />
        </svg>
        <span className="text-white text-xs font-bold tracking-wider uppercase">Direct Arrival</span>
      </div>
    ),
    emerald: (
      <div className="flex items-center gap-2">
        <svg viewBox="0 0 24 24" className="w-8 h-8 text-emerald-200 stroke-current" fill="none" strokeWidth="2">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
          <polyline points="9 22 9 12 15 12 15 22" />
        </svg>
        <span className="text-white text-xs font-bold tracking-wider uppercase">Housing & Living</span>
      </div>
    ),
    indigo: (
      <div className="flex items-center gap-2">
        <svg viewBox="0 0 24 24" className="w-8 h-8 text-indigo-200 stroke-current" fill="none" strokeWidth="2">
          <rect x="2" y="7" width="20" height="14" rx="2" ry="2" />
          <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
        </svg>
        <span className="text-white text-xs font-bold tracking-wider uppercase">Career & Employment</span>
      </div>
    ),
    navy: (
      <div className="flex items-center gap-2">
        <svg viewBox="0 0 24 24" className="w-8 h-8 text-amber-300 stroke-current" fill="none" strokeWidth="2">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
        </svg>
        <span className="text-amber-300 text-xs font-bold tracking-wider uppercase">All-Inclusive VIP</span>
      </div>
    )
  };

  return (
    <div className={`w-full h-28 bg-gradient-to-r ${gradientMap[theme]} rounded-t-xl p-3 flex items-center justify-between overflow-hidden relative shadow-inner`}>
      <div className="relative z-10">{iconScene[theme]}</div>
      {/* Abstract light burst overlay */}
      <div className="absolute -right-4 -bottom-4 w-28 h-28 bg-white/10 rounded-full blur-xl pointer-events-none" />
      <div className="absolute top-2 right-2 text-[10px] font-mono font-medium text-white/70">
        UK READY
      </div>
    </div>
  );
}
