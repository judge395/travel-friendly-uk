import { ShieldCheck, HeartHandshake, Compass, ArrowRight } from 'lucide-react';

interface AboutSectionProps {
  onLearnMore: () => void;
}

export function AboutSection({ onLearnMore }: AboutSectionProps) {
  return (
    <section id="about" className="py-20 lg:py-28 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Overlapping Visual Cards as in screenshot */}
          <div className="lg:col-span-6 relative">
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              
              {/* Primary Card: Greeter holding 'Welcome to the UK' sign */}
              <div className="w-4/5 aspect-[4/5] rounded-2xl overflow-hidden shadow-xl border border-slate-200/80 bg-gradient-to-br from-sky-100 via-slate-50 to-blue-100 relative group">
                {/* Airport Arrival Hall Scene */}
                <div className="absolute inset-0 bg-slate-900/10 z-0" />
                
                {/* Arrival Hall Glass Windows & Architecture */}
                <div className="absolute inset-0 flex flex-col justify-between p-4">
                  <div className="w-full flex justify-between items-center text-[10px] text-slate-500 font-medium">
                    <span className="bg-white/80 px-2 py-0.5 rounded backdrop-blur-xs">Heathrow Terminal 2 & 5</span>
                    <span className="text-emerald-600 font-bold">● Flight Landed</span>
                  </div>

                  {/* Representative Character: Friendly Arrival Guide */}
                  <div className="relative flex flex-col items-center justify-center my-auto">
                    <svg viewBox="0 0 200 240" className="w-56 h-64 drop-shadow-lg">
                      {/* Person Silhouette with Professional Coat & Smile */}
                      {/* Hair */}
                      <path d="M70 50 C 60 20, 140 20, 130 50 C 145 65, 140 100, 130 110 L 70 110 C 60 100, 55 65, 70 50 Z" fill="#1e293b" />
                      {/* Face */}
                      <ellipse cx="100" cy="65" rx="22" ry="26" fill="#fbcfe8" />
                      {/* Eyes & Smile */}
                      <circle cx="92" cy="62" r="2.5" fill="#0f172a" />
                      <circle cx="108" cy="62" r="2.5" fill="#0f172a" />
                      <path d="M92 74 Q 100 82 108 74" stroke="#0f172a" strokeWidth="2" fill="none" strokeLinecap="round" />
                      {/* Long Hair sides */}
                      <path d="M75 55 L 70 120 L 80 120 L 80 80 Z" fill="#0f172a" />
                      <path d="M125 55 L 130 120 L 120 120 L 120 80 Z" fill="#0f172a" />
                      {/* Blazer / Coat */}
                      <path d="M60 105 L 100 95 L 140 105 L 150 200 L 50 200 Z" fill="#0f2744" />
                      {/* Shirt / Scarf */}
                      <polygon points="100,95 85,140 115,140" fill="#ffffff" />
                      <line x1="100" y1="140" x2="100" y2="200" stroke="#0284c7" strokeWidth="4" />
                      {/* Lanyard with Travel Friendly UK badge */}
                      <path d="M85 105 L 96 150 L 100 150 L 115 105" stroke="#38bdf8" strokeWidth="2" fill="none" />
                      <rect x="92" y="150" width="16" height="22" rx="2" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1" />
                      <rect x="94" y="153" width="12" height="3" fill="#0284c7" />
                    </svg>

                    {/* "Welcome to the UK" Placcard Sign */}
                    <div className="absolute -bottom-2 bg-white px-5 py-3 rounded-xl shadow-2xl border-2 border-sky-600 text-center transform -rotate-1 hover:rotate-0 transition-transform">
                      <div className="text-xs font-extrabold text-[#0B3056] tracking-wider uppercase">
                        Welcome
                      </div>
                      <div className="text-base font-black text-sky-600 tracking-wide font-heading">
                        to the UK
                      </div>
                    </div>
                  </div>

                  <div className="text-center text-[11px] text-slate-500 font-medium">
                    Personalized Meet & Greet on Arrival
                  </div>
                </div>
              </div>

              {/* Secondary Overlapping Card: Big Ben / Westminster Bridge */}
              <div className="absolute -bottom-8 right-2 sm:right-6 w-3/5 aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl border-4 border-white bg-gradient-to-tr from-amber-200 via-sky-200 to-amber-100 z-10 group-hover:scale-105 transition-transform duration-300">
                <div className="relative w-full h-full">
                  {/* London Landmark vector */}
                  <svg viewBox="0 0 240 160" className="w-full h-full object-cover">
                    <defs>
                      <linearGradient id="skyGolden" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#bae6fd" />
                        <stop offset="60%" stopColor="#fef08a" />
                        <stop offset="100%" stopColor="#fdba74" />
                      </linearGradient>
                    </defs>
                    <rect width="240" height="160" fill="url(#skyGolden)" />
                    {/* Big Ben Tower Detail */}
                    <path d="M60 160 L 60 55 L 56 55 L 64 25 L 72 25 L 80 55 L 76 55 L 76 160 Z" fill="#78350f" />
                    <circle cx="68" cy="62" r="5" fill="#fef08a" />
                    {/* Westminster Abbey & Palace roofs */}
                    <path d="M80 160 L 80 85 L 140 85 L 140 160 Z" fill="#92400e" />
                    <path d="M140 160 L 140 95 L 200 95 L 200 160 Z" fill="#78350f" />
                    {/* Westminster Bridge Arches */}
                    <rect x="0" y="130" width="240" height="14" fill="#64748b" />
                    <ellipse cx="40" cy="144" rx="16" ry="8" fill="#1e293b" />
                    <ellipse cx="80" cy="144" rx="16" ry="8" fill="#1e293b" />
                    <ellipse cx="120" cy="144" rx="16" ry="8" fill="#1e293b" />
                    <ellipse cx="160" cy="144" rx="16" ry="8" fill="#1e293b" />
                    <ellipse cx="200" cy="144" rx="16" ry="8" fill="#1e293b" />
                    {/* Thames River */}
                    <rect x="0" y="144" width="240" height="16" fill="#0284c7" opacity="0.6" />
                  </svg>

                  <div className="absolute top-2 right-2 bg-slate-900/80 text-white text-[9px] font-semibold px-2 py-0.5 rounded-full backdrop-blur-xs">
                    London, UK
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Right Column: Copy, 3 Highlights, Action */}
          <div className="lg:col-span-6 space-y-6">
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-sky-600">
                About Us
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold font-heading text-slate-900 tracking-tight leading-tight">
                More Than an Airport Pickup
              </h2>
            </div>

            <p className="text-slate-600 text-base leading-relaxed">
              Arriving in a new country is more than just getting off a plane. It’s the beginning of a new journey. At Travel Friendly UK, we help newcomers with the practical things they need after arriving in the UK. Instead of trying to figure everything out alone, you can have someone to guide you through the early stages of settling in.
            </p>

            {/* 3 Pillars / Feature Highlights as in screenshot */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-2">
              {/* Feature 1 */}
              <div className="p-3.5 rounded-xl bg-teal-50/70 border border-teal-100 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-teal-100 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5 text-teal-700" />
                </div>
                <div className="leading-tight">
                  <span className="text-xs font-bold text-teal-950 block">Arrive with</span>
                  <span className="text-xs font-semibold text-teal-700">confidence</span>
                </div>
              </div>

              {/* Feature 2 */}
              <div className="p-3.5 rounded-xl bg-sky-50/70 border border-sky-100 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-sky-100 flex items-center justify-center shrink-0">
                  <HeartHandshake className="w-5 h-5 text-sky-700" />
                </div>
                <div className="leading-tight">
                  <span className="text-xs font-bold text-sky-950 block">Settle with</span>
                  <span className="text-xs font-semibold text-sky-700">support</span>
                </div>
              </div>

              {/* Feature 3 */}
              <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-100 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center shrink-0">
                  <Compass className="w-5 h-5 text-emerald-700" />
                </div>
                <div className="leading-tight">
                  <span className="text-xs font-bold text-emerald-950 block">Start your journey</span>
                  <span className="text-xs font-semibold text-emerald-700">the right way</span>
                </div>
              </div>
            </div>

            {/* Learn More Button */}
            <div className="pt-2">
              <button
                onClick={onLearnMore}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-[#0B3056] hover:bg-[#07213d] text-white font-semibold text-sm shadow-md hover:shadow-lg transition-all active:scale-95 cursor-pointer"
              >
                <span>Learn More</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
