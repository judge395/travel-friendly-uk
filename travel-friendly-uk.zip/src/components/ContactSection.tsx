import { useState, useEffect } from 'react';
import { Mail, MapPin, Phone, Send, CheckCircle2, AlertCircle } from 'lucide-react';
import { UK_AIRPORTS } from '../data/siteData';

interface ContactSectionProps {
  preselectedPackage?: string;
  preselectedService?: string;
}

export function ContactSection({ preselectedPackage, preselectedService }: ContactSectionProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    arrivalDate: '',
    airport: 'London Heathrow (LHR)',
    packageChoice: preselectedPackage || '',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (preselectedPackage) {
      setFormData(prev => ({
        ...prev,
        packageChoice: preselectedPackage,
        message: prev.message ? prev.message : `Hi, I am interested in booking the "${preselectedPackage}". Please let me know the availability and next steps.`
      }));
    } else if (preselectedService) {
      setFormData(prev => ({
        ...prev,
        message: prev.message ? prev.message : `Hi, I would like more information and pricing for "${preselectedService}".`
      }));
    }
  }, [preselectedPackage, preselectedService]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    if (!formData.message.trim()) {
      setErrorMsg('Please write a brief message or requirements.');
      return;
    }

    setErrorMsg('');
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 lg:py-28 bg-slate-50/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Contact Information */}
          <div className="lg:col-span-5 space-y-6">
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-sky-600">
                Contact Us
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold font-heading text-slate-900 tracking-tight leading-tight">
                Ready to Start Your UK Journey?
              </h2>
            </div>

            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              Tell us about your arrival and what support you need. We are here to help! Whether it’s airport transport, student accommodation, or National Insurance guidance, our on-ground team is ready.
            </p>

            {/* Direct Contact Cards */}
            <div className="space-y-4 pt-2">
              {/* Email */}
              <div className="flex items-center gap-4 p-3.5 bg-white rounded-xl border border-slate-200/80 shadow-xs">
                <div className="w-10 h-10 rounded-lg bg-sky-100 flex items-center justify-center text-sky-700 shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-slate-500 block">Email Us Directly</span>
                  <a href="mailto:travelfriendly.uk@gmail.com" className="text-sm font-bold text-slate-900 hover:text-sky-600 transition-colors">
                    travelfriendly.uk@gmail.com
                  </a>
                </div>
              </div>

              {/* Location */}
              <div className="flex items-center gap-4 p-3.5 bg-white rounded-xl border border-slate-200/80 shadow-xs">
                <div className="w-10 h-10 rounded-lg bg-teal-100 flex items-center justify-center text-teal-700 shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-slate-500 block">Location</span>
                  <span className="text-sm font-bold text-slate-900">
                    United Kingdom (London & Nationwide)
                  </span>
                </div>
              </div>

              {/* Phone */}
              <div className="flex items-center gap-4 p-3.5 bg-white rounded-xl border border-slate-200/80 shadow-xs">
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center text-amber-700 shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-slate-500 block">Helpline & WhatsApp</span>
                  <a href="tel:+441234567890" className="text-sm font-bold text-slate-900 hover:text-sky-600 transition-colors">
                    +44 123 456 7890 <span className="text-xs text-slate-400 font-normal">(Optional)</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Quick Guarantees */}
            <div className="p-4 rounded-xl bg-sky-100/60 border border-sky-200/70 text-xs text-slate-700 space-y-1.5">
              <div className="font-bold text-sky-950 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-sky-700" />
                <span>Fast 24-Hour Response Guarantee</span>
              </div>
              <p className="text-slate-600 pl-5">
                All requests are reviewed by an experienced UK relocation specialist. No spam, no obligation.
              </p>
            </div>
          </div>

          {/* Right Column: Send Us Your Enquiry Form Card */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-md">
              <h3 className="text-lg font-bold text-slate-900 font-heading mb-6 pb-3 border-b border-slate-100">
                Send Us Your Enquiry
              </h3>

              {submitted ? (
                <div className="py-8 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
                    <CheckCircle2 className="w-9 h-9" />
                  </div>
                  <h4 className="text-xl font-bold text-slate-900 font-heading">
                    Thank You, {formData.name}!
                  </h4>
                  <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
                    Your enquiry has been received. Our team will contact you at <span className="font-semibold text-slate-900">{formData.email}</span> within 24 hours to organize your arrival details.
                  </p>
                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({
                        name: '',
                        email: '',
                        phone: '',
                        arrivalDate: '',
                        airport: 'London Heathrow (LHR)',
                        packageChoice: '',
                        message: ''
                      });
                    }}
                    className="inline-flex px-4 py-2 text-xs font-semibold text-sky-700 bg-sky-50 rounded-lg hover:bg-sky-100 transition-colors"
                  >
                    Submit Another Enquiry
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {errorMsg && (
                    <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  {/* 2-Column Fields: Name & Email */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Jahid Hasan"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-600 text-slate-900 placeholder:text-slate-400"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        placeholder="e.g. name@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-600 text-slate-900 placeholder:text-slate-400"
                        required
                      />
                    </div>
                  </div>

                  {/* 2-Column Fields: Arrival Date & Airport */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Arrival Date
                      </label>
                      <input
                        type="date"
                        value={formData.arrivalDate}
                        onChange={(e) => setFormData({ ...formData, arrivalDate: e.target.value })}
                        className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-600 text-slate-900"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Airport
                      </label>
                      <select
                        value={formData.airport}
                        onChange={(e) => setFormData({ ...formData, airport: e.target.value })}
                        className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-600 text-slate-900 bg-white"
                      >
                        {UK_AIRPORTS.map((airport) => (
                          <option key={airport} value={airport}>
                            {airport}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Package Selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Preferred Package (Optional)
                    </label>
                    <select
                      value={formData.packageChoice}
                      onChange={(e) => setFormData({ ...formData, packageChoice: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-600 text-slate-900 bg-white"
                    >
                      <option value="">-- Choose a package or custom enquiry --</option>
                      <option value="Arrival Package (From £99)">Arrival Package (From £99)</option>
                      <option value="Settle-In Package (From £199)">Settle-In Package (From £199)</option>
                      <option value="Job Start Package (From £149)">Job Start Package (From £149)</option>
                      <option value="Complete UK Start Package (From £299)">Complete UK Start Package (From £299)</option>
                      <option value="Single Standalone Service">Single Standalone Service</option>
                    </select>
                  </div>

                  {/* Message / Requirements */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Your Message / Requirements *
                    </label>
                    <textarea
                      rows={4}
                      placeholder="Please share details such as flight number, number of passengers, luggage count, destination city, or any specific support you need..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-600 text-slate-900 placeholder:text-slate-400"
                      required
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="w-full py-3.5 px-4 rounded-lg bg-[#0B3056] hover:bg-[#07213d] text-white font-bold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Message</span>
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
