import { ArrowRight, Plane, Home, Briefcase, FileText, Smartphone, Bus, MapPin, Sparkles } from 'lucide-react';
import { QUICK_SERVICES } from '../data/siteData';

interface HeroSectionProps {
  onGetStarted: () => void;
  onContactClick: () => void;
  onSelectQuickService: (serviceId: string) => void;
}

export function HeroSection({
  onGetStarted,
  onContactClick,
  onSelectQuickService
}: HeroSectionProps) {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Plane':
        return <Plane className="w-5 h-5 text-sky-600" />;
      case 'Home':
        return <Home className="w-5 h-5 text-sky-600" />;
      case 'Briefcase':
        return <Briefcase className="w-5 h-5 text-sky-600" />;
      case 'FileText':
        return <FileText className="w-5 h-5 text-sky-600" />;
      case 'Smartphone':
        return <Smartphone className="w-5 h-5 text-sky-600" />;
      case 'Bus':
        return <Bus className="w-5 h-5 text-sky-600" />;
      case 'MapPin':
      default:
        return <MapPin className="w-5 h-5 text-sky-600" />;
    }
  };

  return (
    <section id="home" className="relative pt-24 pb-16 lg:pt-28 lg:pb-24 overflow-hidden bg-gradient-to-b from-[#0B2545] via-[#0E345E] to-[#134074] text-white">
      {/* Background Graphic: Westminster Silhouette & Twilight Glow */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-40 mix-blend-screen">
        <svg
          viewBox="0 0 1440 600"
          className="w-full h-full object-cover"
          preserveAspectRatio="none"
        >
          <defs>
            <radialGradient id="skyGlow" cx="65%" cy="30%" r="50%">
              <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.45" />
              <stop offset="60%" stopColor="#0B2545" stopOpacity="0.1" />
              <stop offset="100%" stopColor="#0B2545" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="1440" height="600" fill="url(#skyGlow)" />
          {/* Subtle London Skyline Silhouette on the right */}
          <g fill="#081b33" opacity="0.85" transform="translate(650, 260) scale(1.1)">
            {/* Westminster palace & Big ben */}
            <path d="M0 340 L 0 160 L 40 160 L 40 340 Z" />
            <path d="M45 340 L 45 130 L 100 130 L 100 340 Z" />
            <path d="M105 340 L 105 80 L 98 80 L 115 10 L 132 80 L 125 80 L 125 340 Z" />
            <circle cx="115" cy="90" r="12" fill="#FDE047" opacity="0.6" />
            <path d="M135 340 L 135 150 L 220 150 L 220 340 Z" />
            <path d="M225 340 L 225 180 L 320 180 L 320 340 Z" />
            <path d="M330 340 L 330 140 L 420 140 L 420 340 Z" />
            <path d="M430 340 L 430 190 L 520 190 L 520 340 Z" />
          </g>
        </svg>
      </div>

      {/* Airplane Soaring Graphic in Twilight Sky */}
      <div className="absolute top-16 right-1/4 md:right-1/3 opacity-75 z-0 animate-pulse">
        <svg viewBox="0 0 120 60" className="w-24 h-12 text-sky-200 fill-current drop-shadow-lg">
          <path d="M10 32 L40 18 L55 18 L48 30 L80 30 L95 22 L102 22 L98 30 L110 30 L107 35 L96 35 L48 35 L36 50 L24 50 L32 35 L10 35 Z" />
        </svg>
      </div>

      {/* Main Hero Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Headlines & CTA */}
          <div className="lg:col-span-7 space-y-6">
            {/* Kicker */}
            <div className="inline-flex items-center gap-2 text-xs md:text-sm font-semibold tracking-wider uppercase text-sky-300">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Welcome to Travel Friendly UK</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-[3.5rem] font-extrabold tracking-tight leading-[1.15] font-heading text-balance">
              From Arrival to <br className="hidden sm:inline" />
              Your <span className="text-amber-400">New Beginning.</span>
            </h1>

            {/* Subtitle */}
            <p className="text-slate-200 text-base sm:text-lg max-w-2xl font-normal leading-relaxed">
              Airport pickup, accommodation, job-search support, NI guidance and practical help for starting life in the UK.
            </p>

            {/* Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={onGetStarted}
                className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm sm:text-base shadow-lg shadow-amber-500/20 hover:shadow-amber-500/35 transition-all duration-200 active:scale-95 cursor-pointer"
              >
                <span>Get Started</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onContactClick}
                className="inline-flex items-center px-6 py-3.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-sm sm:text-base border border-white/25 hover:border-white/50 backdrop-blur-xs transition-all duration-200 active:scale-95 cursor-pointer"
              >
                Contact Us
              </button>
            </div>
          </div>

          {/* Right Column: Hero Visual Graphic / Backpacker Overlooking London */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="relative w-full max-w-md aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl border border-white/20 bg-gradient-to-tr from-slate-900 via-sky-950 to-blue-900 group">
              {/* London Westminster Sky & Water Vector */}
              <div className="absolute inset-0 bg-cover bg-center">
                {/* Twilight skyline simulation */}
                <svg viewBox="0 0 400 300" className="w-full h-full object-cover">
                  <defs>
                    <linearGradient id="twilightGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#1e3a8a" />
                      <stop offset="50%" stopColor="#3b82f6" />
                      <stop offset="70%" stopColor="#fdba74" />
                      <stop offset="100%" stopColor="#1e293b" />
                    </linearGradient>
                  </defs>
                  <rect width="400" height="300" fill="url(#twilightGrad)" />
                  {/* Glowing Sun over river */}
                  <circle cx="280" cy="180" r="30" fill="#fef08a" opacity="0.7" filter="blur(8px)" />
                  {/* Distant Parliament silhouettes */}
                  <g fill="#0f172a">
                    <rect x="180" y="140" width="16" height="50" />
                    <rect x="200" y="120" width="22" height="70" />
                    <polygon points="211,70 205,120 217,120" />
                    <rect x="225" y="150" width="70" height="40" />
                    <rect x="300" y="135" width="40" height="55" />
                  </g>
                  {/* River Thames Reflection */}
                  <rect x="0" y="190" width="400" height="110" fill="#0f172a" opacity="0.85" />
                  <ellipse cx="280" cy="205" rx="40" ry="10" fill="#fde047" opacity="0.3" filter="blur(4px)" />
                </svg>
              </div>

              {/* Traveler with Backpack facing London */}
              <div className="absolute bottom-0 right-10 flex flex-col items-center">
                <svg viewBox="0 0 140 180" className="w-36 h-48 drop-shadow-2xl">
                  {/* Backpacker Silhouette */}
                  {/* Head & Hair */}
                  <circle cx="70" cy="40" r="16" fill="#1e293b" />
                  {/* Neck */}
                  <rect x="65" y="55" width="10" height="8" fill="#1e293b" />
                  {/* Backpack */}
                  <rect x="52" y="62" width="36" height="48" rx="8" fill="#091e3a" stroke="#38bdf8" strokeWidth="1.5" />
                  <path d="M58 85 L82 85" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 2" />
                  {/* Shoulders & Jacket */}
                  <path d="M40 70 Q 70 58 100 70 L 96 150 L 44 150 Z" fill="#0f2942" />
                  {/* Arm holding backpack straps */}
                  <path d="M42 75 L 50 115" stroke="#1e293b" strokeWidth="10" strokeLinecap="round" />
                  <path d="M98 75 L 90 115" stroke="#1e293b" strokeWidth="10" strokeLinecap="round" />
                </svg>
              </div>

              {/* Glass Tag on Image */}
              <div className="absolute top-4 left-4 bg-slate-950/70 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/20 text-xs font-medium text-white flex items-center gap-1.5 shadow-lg">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>UK Arrival Assistance</span>
              </div>

              {/* Bottom Quote Banner */}
              <div className="absolute bottom-4 left-4 right-4 bg-white/10 backdrop-blur-md p-2.5 rounded-xl border border-white/15 text-[11px] text-slate-100 flex items-center justify-between">
                <span>Safe · Reliable · Affordable</span>
                <span className="font-semibold text-amber-300">London & Nationwide</span>
              </div>
            </div>
          </div>
        </div>

        {/* Floating Quick Services Strip (As shown in screenshot) */}
        <div className="mt-12 lg:mt-16 bg-white text-slate-800 rounded-2xl shadow-xl border border-slate-100 p-3 sm:p-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 sm:gap-4">
            {QUICK_SERVICES.map((item) => (
              <button
                key={item.id}
                onClick={() => onSelectQuickService(item.id)}
                className="flex flex-col items-center text-center p-3 rounded-xl hover:bg-sky-50/70 transition-all duration-150 group cursor-pointer focus:outline-none focus:ring-2 focus:ring-sky-500/20"
              >
                <div className="w-11 h-11 rounded-full bg-sky-100 group-hover:bg-sky-600 transition-colors flex items-center justify-center mb-2 shadow-xs">
                  <div className="group-hover:text-white transition-colors">
                    {getIcon(item.icon)}
                  </div>
                </div>
                <span className="text-xs font-bold text-slate-800 group-hover:text-sky-700 leading-tight">
                  {item.name}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
