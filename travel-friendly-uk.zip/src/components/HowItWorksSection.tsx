import { JOURNEY_STEPS } from '../data/siteData';
import { Calendar, CheckSquare, ClipboardCheck, Plane, Key, Compass, ArrowRight } from 'lucide-react';

interface HowItWorksProps {
  onStartJourney: () => void;
}

export function HowItWorksSection({ onStartJourney }: HowItWorksProps) {
  const getStepIcon = (iconName: string) => {
    const iconClass = "w-5 h-5 text-sky-600";
    switch (iconName) {
      case 'Calendar':
        return <Calendar className={iconClass} />;
      case 'CheckSquare':
        return <CheckSquare className={iconClass} />;
      case 'ClipboardCheck':
        return <ClipboardCheck className={iconClass} />;
      case 'PlaneTakeoff':
        return <Plane className={iconClass} />;
      case 'Key':
        return <Key className={iconClass} />;
      case 'Compass':
      default:
        return <Compass className={iconClass} />;
    }
  };

  return (
    <section id="how-it-works" className="py-20 lg:py-28 bg-slate-50/70 border-t border-b border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-sky-600">
            How It Works
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-heading text-slate-900 tracking-tight">
            Your Journey With Travel Friendly
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Step-by-step guidance designed to make your move completely stress-free.
          </p>
        </div>

        {/* 6 Step Cards with Connecting Arrow Indicators */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 relative">
          {JOURNEY_STEPS.map((step, idx) => (
            <div key={step.step} className="relative flex flex-col">
              <div className="bg-white rounded-xl border border-slate-200/80 p-4 shadow-xs hover:shadow-md transition-shadow flex-1 flex flex-col justify-between group">
                
                <div>
                  {/* Step Number badge and Icon */}
                  <div className="flex items-center justify-between mb-3">
                    <span className="w-6 h-6 rounded-full bg-sky-100 text-sky-800 text-xs font-extrabold flex items-center justify-center font-mono">
                      {step.step}
                    </span>
                    <div className="w-8 h-8 rounded-lg bg-sky-50 flex items-center justify-center group-hover:bg-sky-500 group-hover:text-white transition-colors">
                      {getStepIcon(step.iconName)}
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-sm font-bold text-slate-900 font-heading mb-2 leading-snug">
                    {step.title}
                  </h3>

                  {/* Description */}
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {/* Sub-highlights */}
                <div className="mt-4 pt-3 border-t border-slate-100 space-y-1">
                  {step.highlights.map((h, i) => (
                    <div key={i} className="text-[10px] text-slate-500 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                      <span className="truncate">{h}</span>
                    </div>
                  ))}
                </div>

              </div>

              {/* Connecting arrow for desktop between steps */}
              {idx < JOURNEY_STEPS.length - 1 && (
                <div className="hidden lg:flex absolute -right-3 top-1/2 -translate-y-1/2 z-10 text-slate-300">
                  <ArrowRight className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Bottom CTA Banner */}
        <div className="mt-12 text-center">
          <button
            onClick={onStartJourney}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#0B3056] hover:bg-[#07213d] text-white font-semibold text-xs sm:text-sm shadow-md transition-all active:scale-95 cursor-pointer"
          >
            <span>Begin Your Journey Today</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
}
