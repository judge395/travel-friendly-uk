import { useState } from 'react';
import { FAQS } from '../data/siteData';
import { ChevronDown, Plus, Minus, HelpCircle, Sparkles } from 'lucide-react';

interface FaqSectionProps {
  onContactClick: () => void;
}

export function FaqSection({ onContactClick }: FaqSectionProps) {
  const [openFaqId, setOpenFaqId] = useState<string | null>('faq-1');

  const toggleFaq = (id: string) => {
    setOpenFaqId(openFaqId === id ? null : id);
  };

  return (
    <section id="faqs" className="py-20 lg:py-28 bg-white border-b border-slate-200/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: Heading & CTA */}
          <div className="lg:col-span-4 space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-sky-600">
              FAQ
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold font-heading text-slate-900 tracking-tight leading-tight">
              Frequently Asked Questions
            </h2>
            <p className="text-slate-600 text-sm leading-relaxed">
              Find answers to common questions about our airport pickup, accommodation, NI guidance and UK newcomer packages.
            </p>
            <div className="pt-2">
              <button
                onClick={onContactClick}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#0B3056] hover:bg-[#07213d] text-white font-semibold text-xs shadow-sm transition-all active:scale-95 cursor-pointer"
              >
                <span>View All FAQs / Ask Us</span>
              </button>
            </div>
          </div>

          {/* Middle Column: Interactive Accordion */}
          <div className="lg:col-span-5 space-y-3">
            {FAQS.map((faq) => {
              const isOpen = openFaqId === faq.id;
              return (
                <div
                  key={faq.id}
                  className="border border-slate-200 rounded-xl overflow-hidden transition-all duration-200 bg-white"
                >
                  <button
                    onClick={() => toggleFaq(faq.id)}
                    className="w-full py-4 px-4 sm:px-5 flex items-center justify-between gap-4 text-left hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    <span className="text-sm font-bold text-slate-800 leading-snug">
                      {faq.question}
                    </span>
                    <span className="text-slate-400 shrink-0">
                      {isOpen ? (
                        <Minus className="w-4 h-4 text-sky-600" />
                      ) : (
                        <Plus className="w-4 h-4 text-slate-500" />
                      )}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="px-4 sm:px-5 pb-4 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Right Column: "Your Questions Matter" Visual Card as in screenshot */}
          <div className="lg:col-span-3">
            <div className="rounded-2xl border border-sky-100 bg-gradient-to-br from-sky-50 via-white to-blue-50/80 p-5 shadow-sm text-center flex flex-col items-center justify-between h-full min-h-[280px]">
              {/* Graphic Scene: Traveler at airport glass window */}
              <div className="w-full aspect-[4/3] rounded-xl overflow-hidden bg-slate-100 border border-slate-200/80 relative mb-4 flex items-center justify-center">
                {/* Airport window grid vector */}
                <svg viewBox="0 0 200 150" className="w-full h-full object-cover">
                  {/* Sky through window */}
                  <rect width="200" height="150" fill="#e0f2fe" />
                  {/* Window structural beams */}
                  <line x1="50" y1="0" x2="50" y2="150" stroke="#cbd5e1" strokeWidth="4" />
                  <line x1="150" y1="0" x2="150" y2="150" stroke="#cbd5e1" strokeWidth="4" />
                  <line x1="0" y1="75" x2="200" y2="75" stroke="#cbd5e1" strokeWidth="4" />
                  {/* Silhouette of traveler looking outside */}
                  <g fill="#1e293b" transform="translate(85, 45)">
                    <circle cx="15" cy="15" r="10" />
                    <rect x="5" y="25" width="20" height="40" rx="4" />
                    {/* Backpack on person */}
                    <rect x="0" y="28" width="8" height="24" rx="2" fill="#0f172a" />
                  </g>
                </svg>

                {/* Floating Badge */}
                <div className="absolute bottom-2 right-2 bg-white/90 backdrop-blur-xs px-2 py-0.5 rounded text-[10px] font-bold text-sky-800 shadow-xs">
                  24/7 Assistance
                </div>
              </div>

              {/* Card Text & Sparkle */}
              <div className="space-y-1.5">
                <div className="inline-flex items-center gap-1 text-sky-600 font-extrabold text-base font-heading">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Your Questions Matter</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Have a specific question about your UK flight, visa status, or luggage?
                </p>
              </div>

              <button
                onClick={onContactClick}
                className="mt-4 w-full py-2 px-3 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                Chat with an Advisor
              </button>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
