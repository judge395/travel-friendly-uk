import { Star, Quote, CheckCircle } from 'lucide-react';
import { TESTIMONIALS } from '../data/siteData';

export function TestimonialsSection() {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden bg-slate-900 text-white">
      {/* Twilight Thames & London Bridge Panoramic Backdrop */}
      <div className="absolute inset-0 z-0">
        <svg viewBox="0 0 1440 600" className="w-full h-full object-cover" preserveAspectRatio="none">
          <defs>
            <linearGradient id="sunsetGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#1e293b" />
              <stop offset="35%" stopColor="#334155" />
              <stop offset="55%" stopColor="#b45309" stopOpacity="0.8" />
              <stop offset="70%" stopColor="#d97706" stopOpacity="0.9" />
              <stop offset="85%" stopColor="#78350f" />
              <stop offset="100%" stopColor="#0f172a" />
            </linearGradient>
          </defs>
          <rect width="1440" height="600" fill="url(#sunsetGrad)" />

          {/* Golden reflections on the water */}
          <ellipse cx="720" cy="520" rx="600" ry="80" fill="#f59e0b" opacity="0.35" filter="blur(30px)" />
          
          {/* Silhouetted skyline across horizon */}
          <g fill="#0b1320" opacity="0.95" transform="translate(0, 240)">
            {/* Westminster Palace silhouettes */}
            <path d="M0,160 L100,160 L100,90 L120,90 L120,160 L240,160 L240,110 L250,70 L260,110 L260,160 L400,160 L400,120 L440,120 L440,160 L600,160 L600,80 L620,80 L620,160 L700,160 L700,40 L695,40 L705,10 L715,10 L725,40 L720,40 L720,160 L850,160 L850,110 L920,110 L920,160 L1100,160 L1100,130 L1200,130 L1200,160 L1440,160 L1440,360 L0,360 Z" />
            {/* Big Ben illuminated clock face */}
            <circle cx="710" cy="55" r="7" fill="#fef08a" opacity="0.9" />
          </g>
          {/* River Thames surface */}
          <rect y="400" width="1440" height="200" fill="#0f172a" opacity="0.75" />
        </svg>
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
            What Our Customers Say
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-heading text-white tracking-tight">
            Real People. Real Journeys.
          </h2>
          <p className="text-slate-200 text-sm sm:text-base leading-relaxed">
            Here’s what some of our customers say about their experience with Travel Friendly UK.
          </p>
        </div>

        {/* 3 Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((item) => (
            <div
              key={item.id}
              className="bg-white/95 backdrop-blur-md rounded-2xl p-6 text-slate-800 shadow-2xl border border-white/20 flex flex-col justify-between hover:-translate-y-1 transition-transform duration-200"
            >
              <div>
                {/* Avatar and Verification */}
                <div className="flex items-center gap-3.5 mb-4">
                  <div className={`w-12 h-12 rounded-full ${item.avatarBg} font-bold text-sm flex items-center justify-center shadow-inner`}>
                    {item.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 leading-tight">
                      {item.name}
                    </h4>
                    <span className="text-xs text-slate-500 font-medium">
                      {item.role}
                    </span>
                  </div>
                  <div className="ml-auto text-emerald-600 flex items-center gap-1 text-[11px] font-semibold bg-emerald-50 px-2 py-0.5 rounded-full">
                    <CheckCircle className="w-3 h-3" />
                    <span>Verified</span>
                  </div>
                </div>

                {/* Quote Text */}
                <div className="relative mb-4">
                  <Quote className="w-6 h-6 text-sky-200 absolute -top-2 -left-1 opacity-50" />
                  <p className="text-xs sm:text-sm text-slate-700 leading-relaxed italic relative z-10 pl-2">
                    "{item.quote}"
                  </p>
                </div>
              </div>

              {/* Bottom: Author & 5 Yellow Stars */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">
                  — {item.name}, {item.role}
                </span>
                <div className="flex items-center gap-1">
                  {[...Array(item.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  ))}
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Trust Badges */}
        <div className="mt-12 text-center text-xs text-slate-300 flex flex-wrap items-center justify-center gap-6">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            Over 500+ Newcomers Assisted
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            4.9 / 5.0 Average Customer Rating
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-sky-400" />
            100% Dedicated UK On-Ground Team
          </span>
        </div>

      </div>
    </section>
  );
}
