import { PACKAGES, PackageItem } from '../data/siteData';
import { PackageVisualCard } from './VisualIllustrations';
import { Check } from 'lucide-react';

interface PackagesSectionProps {
  onSelectPackage: (pkg: PackageItem) => void;
}

export function PackagesSection({ onSelectPackage }: PackagesSectionProps) {
  const getButtonClass = (theme: 'sky' | 'emerald' | 'indigo' | 'navy') => {
    switch (theme) {
      case 'sky':
        return 'bg-sky-500 hover:bg-sky-600 text-white shadow-sky-500/20';
      case 'emerald':
        return 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-500/20';
      case 'indigo':
        return 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/20';
      case 'navy':
      default:
        return 'bg-[#0B2545] hover:bg-[#07192f] text-white shadow-blue-900/20';
    }
  };

  const getCheckClass = (theme: 'sky' | 'emerald' | 'indigo' | 'navy') => {
    switch (theme) {
      case 'sky':
        return 'text-sky-500';
      case 'emerald':
        return 'text-emerald-500';
      case 'indigo':
        return 'text-indigo-500';
      case 'navy':
      default:
        return 'text-amber-500';
    }
  };

  return (
    <section id="packages" className="py-20 lg:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-sky-600">
            Our Packages
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-heading text-slate-900 tracking-tight">
            Choose the Support You Need
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Flexible packages designed to give you the right support at the right time.
          </p>
        </div>

        {/* 4 Packages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
          {PACKAGES.map((pkg) => (
            <div
              key={pkg.id}
              className={`rounded-2xl border transition-all duration-200 flex flex-col justify-between overflow-hidden bg-white hover:shadow-xl ${
                pkg.popular
                  ? 'border-slate-300 ring-2 ring-sky-500/20 shadow-md'
                  : 'border-slate-200/90 shadow-sm'
              }`}
            >
              <div>
                {/* Visual Header */}
                <PackageVisualCard theme={pkg.themeColor} />

                {/* Content Box */}
                <div className="p-5 space-y-4">
                  {/* Title & Subtitle */}
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 font-heading">
                      {pkg.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                      {pkg.subtitle}
                    </p>
                  </div>

                  {/* Checklist */}
                  <ul className="space-y-2.5 pt-2 border-t border-slate-100">
                    {pkg.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-xs text-slate-700">
                        <Check className={`w-4 h-4 shrink-0 stroke-[2.5] ${getCheckClass(pkg.themeColor)}`} />
                        <span className="font-medium">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Price & Action Button Footer */}
              <div className="p-5 pt-0 mt-4">
                <div className="mb-3">
                  <span className="text-xs text-slate-500">Starting</span>
                  <div className="text-xl font-extrabold font-heading text-slate-900">
                    {pkg.price}
                  </div>
                </div>

                <button
                  onClick={() => onSelectPackage(pkg)}
                  className={`w-full py-2.5 px-4 rounded-lg font-bold text-xs shadow-md transition-all duration-150 active:scale-95 cursor-pointer text-center ${getButtonClass(
                    pkg.themeColor
                  )}`}
                >
                  Enquire Now
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
