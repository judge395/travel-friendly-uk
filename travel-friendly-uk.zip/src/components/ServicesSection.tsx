import { useState } from 'react';
import { SERVICES, ServiceItem } from '../data/siteData';
import { ServiceVisualCard } from './VisualIllustrations';
import { Plane, Home, Briefcase, FileText, Smartphone, Bus, Building2, MapPin, ArrowRight, CheckCircle2, X } from 'lucide-react';

interface ServicesSectionProps {
  onEnquireService: (serviceName: string) => void;
}

export function ServicesSection({ onEnquireService }: ServicesSectionProps) {
  const [activeModalService, setActiveModalService] = useState<ServiceItem | null>(null);

  const getServiceIcon = (iconName: string) => {
    const iconClass = "w-5 h-5 text-sky-600";
    switch (iconName) {
      case 'Plane':
        return <Plane className={iconClass} />;
      case 'Home':
        return <Home className={iconClass} />;
      case 'Briefcase':
        return <Briefcase className={iconClass} />;
      case 'FileText':
        return <FileText className={iconClass} />;
      case 'Smartphone':
        return <Smartphone className={iconClass} />;
      case 'Bus':
        return <Bus className={iconClass} />;
      case 'Building2':
        return <Building2 className={iconClass} />;
      case 'MapPin':
      default:
        return <MapPin className={iconClass} />;
    }
  };

  return (
    <section id="services" className="py-20 lg:py-28 bg-slate-50/70 border-t border-b border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-sky-600">
            Our Services
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-heading text-slate-900 tracking-tight">
            Everything You Need to Get Started
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            We provide flexible support depending on what you need. From airport pickup to job search, accommodation and everyday settling-in assistance — we are here to help.
          </p>
        </div>

        {/* 8-Card Grid (4 cols on lg, 2 on md, 1 on mobile) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between group"
            >
              <div>
                {/* Icon & Title */}
                <div className="flex items-start gap-3 mb-2.5">
                  <div className="w-10 h-10 rounded-lg bg-sky-50 border border-sky-100 flex items-center justify-center shrink-0 group-hover:bg-sky-600 group-hover:text-white transition-colors">
                    {getServiceIcon(service.iconName)}
                  </div>
                  <h3 className="text-base font-bold text-slate-900 font-heading leading-snug group-hover:text-sky-700 transition-colors">
                    {service.title}
                  </h3>
                </div>

                {/* Short Description */}
                <p className="text-xs text-slate-600 mb-4 line-clamp-2 leading-relaxed">
                  {service.shortDesc}
                </p>

                {/* Visual Thumbnail */}
                <div className="mb-4 overflow-hidden rounded-lg">
                  <ServiceVisualCard type={service.id} title={service.title} />
                </div>
              </div>

              {/* Action Button: Learn More */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={() => setActiveModalService(service)}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-sky-700 hover:text-sky-900 transition-colors group/btn cursor-pointer py-1"
                >
                  <span>Learn More</span>
                  <ArrowRight className="w-3.5 h-3.5 transform group-hover/btn:translate-x-1 transition-transform" />
                </button>
                <span className="text-[10px] text-slate-600 font-medium bg-slate-100 px-2 py-0.5 rounded">
                  {service.category}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Service Detail Modal */}
      {activeModalService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 overflow-hidden relative max-h-[90vh] flex flex-col">
            
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-sky-100 flex items-center justify-center shrink-0">
                  {getServiceIcon(activeModalService.iconName)}
                </div>
                <div>
                  <span className="text-xs font-semibold text-sky-600 uppercase tracking-wider">
                    {activeModalService.category} Support
                  </span>
                  <h3 className="text-xl font-bold text-slate-900 font-heading">
                    {activeModalService.title}
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setActiveModalService(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
                aria-label="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="py-4 space-y-4 overflow-y-auto flex-1">
              {/* Visual preview */}
              <div className="rounded-xl overflow-hidden border border-slate-200">
                <ServiceVisualCard type={activeModalService.id} title={activeModalService.title} />
              </div>

              <p className="text-sm text-slate-700 leading-relaxed font-medium">
                {activeModalService.shortDesc}
              </p>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  What’s Included & Covered:
                </h4>
                <ul className="space-y-2">
                  {activeModalService.details.map((detail, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
              <button
                onClick={() => setActiveModalService(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => {
                  const serviceName = activeModalService.title;
                  setActiveModalService(null);
                  onEnquireService(serviceName);
                }}
                className="px-5 py-2.5 text-xs font-bold text-white bg-[#0B3056] hover:bg-[#07213d] rounded-lg shadow-sm transition-all cursor-pointer"
              >
                Enquire for {activeModalService.title}
              </button>
            </div>

          </div>
        </div>
      )}
    </section>
  );
}
