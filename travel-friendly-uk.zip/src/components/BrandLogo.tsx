export function BrandLogo({
  variant = 'dark',
  size = 'normal'
}: {
  variant?: 'dark' | 'light';
  size?: 'normal' | 'large';
}) {
  const isLight = variant === 'light';
  const headingClass = isLight ? 'text-white' : 'text-slate-900';
  const subtitleClass = isLight ? 'text-slate-300' : 'text-slate-500';

  return (
    <div className="flex items-center gap-2.5 select-none">
      {/* Globe & Airplane Swoosh Mark */}
      <div className="relative w-9 h-9 flex items-center justify-center shrink-0">
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full drop-shadow-sm"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Circular Flight Path */}
          <path
            d="M 22 75 C 10 55 18 28 42 16 C 68 4 92 20 88 50 C 85 75 58 92 34 82"
            stroke={isLight ? '#38BDF8' : '#0284C7'}
            strokeWidth="5.5"
            strokeLinecap="round"
            strokeDasharray="4 2"
          />
          {/* Inner Globe Latitude & Longitude grid lines */}
          <circle
            cx="48"
            cy="50"
            r="26"
            stroke={isLight ? 'rgba(255,255,255,0.4)' : '#0F2744'}
            strokeWidth="3"
            fill={isLight ? 'rgba(56, 189, 248, 0.15)' : '#E0F2FE'}
          />
          <ellipse
            cx="48"
            cy="50"
            rx="14"
            ry="26"
            stroke={isLight ? 'rgba(255,255,255,0.35)' : '#0284C7'}
            strokeWidth="2"
          />
          <line
            x1="22"
            y1="50"
            x2="74"
            y2="50"
            stroke={isLight ? 'rgba(255,255,255,0.35)' : '#0284C7'}
            strokeWidth="2"
          />
          {/* Airplane in Flight */}
          <g transform="translate(14, 20) rotate(-28)">
            <path
              d="M16 2L20 12L32 16L20 18L18 26L14 20L8 20L11 16L6 14L16 2Z"
              fill={isLight ? '#38BDF8' : '#0B3056'}
            />
          </g>
        </svg>
      </div>

      {/* Brand Text Lockup */}
      <div className="flex flex-col justify-center leading-tight">
        <div className={`font-bold font-heading tracking-tight ${headingClass} ${size === 'large' ? 'text-2xl' : 'text-lg'}`}>
          Travel Friendly <span className="text-sky-600 font-extrabold">UK</span>
        </div>
        <span className={`text-[11px] font-medium tracking-wide ${subtitleClass}`}>
          From Arrival to Your New Beginning
        </span>
      </div>
    </div>
  );
}
