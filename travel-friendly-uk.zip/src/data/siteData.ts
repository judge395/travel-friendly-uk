export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  iconName: string;
  details: string[];
  category: string;
  badge?: string;
}

export interface PackageItem {
  id: string;
  name: string;
  subtitle: string;
  price: string;
  priceNumber: number;
  themeColor: 'sky' | 'emerald' | 'indigo' | 'navy';
  badge?: string;
  features: string[];
  popular?: boolean;
}

export interface StepItem {
  step: number;
  title: string;
  description: string;
  iconName: string;
  highlights: string[];
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  rating: number;
  quote: string;
  verified: boolean;
  avatarBg: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export const QUICK_SERVICES = [
  { id: 'airport-pickup', name: 'Airport Pickup & Welcome', icon: 'Plane', target: '#services' },
  { id: 'accommodation', name: 'Accommodation Support', icon: 'Home', target: '#services' },
  { id: 'job-search', name: 'Job Search Support', icon: 'Briefcase', target: '#services' },
  { id: 'ni-guidance', name: 'NI Application Guidance', icon: 'FileText', target: '#services' },
  { id: 'sim-setup', name: 'SIM & Mobile Setup', icon: 'Smartphone', target: '#services' },
  { id: 'transport', name: 'Transport Guidance', icon: 'Bus', target: '#services' },
  { id: 'local-support', name: 'Local Support & More', icon: 'MapPin', target: '#services' },
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'airport-pickup',
    title: 'Airport Pickup & Welcome',
    shortDesc: 'Meet and greet, luggage help and transport to your destination.',
    iconName: 'Plane',
    category: 'Arrival',
    details: [
      'Personal airport meet-and-greet in arrival terminal',
      'Flight tracking to accommodate delays or early arrivals',
      'Luggage handling and comfortable direct transport',
      'Drop-off directly at your accommodation or temporary stay',
      'Covering London Heathrow, Gatwick, Stansted, Luton & City airports'
    ]
  },
  {
    id: 'accommodation',
    title: 'Accommodation Support',
    shortDesc: 'Find suitable accommodation based on your budget and needs.',
    iconName: 'Home',
    category: 'Housing',
    details: [
      'Short-term & long-term student and professional housing assistance',
      'Trusted landlord and agency network checks to avoid scams',
      'Guidance on tenancy agreements, deposits, and council tax rules',
      'Location screening for safety, commute time, and nearby amenities',
      'Virtual viewing assistance and contract review guidance'
    ]
  },
  {
    id: 'job-search',
    title: 'Job Search Support',
    shortDesc: 'CV guidance, job search and application help.',
    iconName: 'Briefcase',
    category: 'Career',
    details: [
      'UK standard CV & Cover Letter formatting and optimization',
      'Targeted job board navigation (LinkedIn, Indeed, Reed, Totaljobs)',
      'Right to Work check guidance & share code explanation',
      'Interview preparation questions and etiquette tips',
      'Networking tips and sector-specific recruitment agency lists'
    ]
  },
  {
    id: 'ni-guidance',
    title: 'NI Application Guidance',
    shortDesc: 'Understand the process and what you need to apply.',
    iconName: 'FileText',
    category: 'Legal & Admin',
    details: [
      'Step-by-step guidance for gov.uk National Insurance number application',
      'Identity document verification checklist (BRP, Visa, Passport)',
      'Job offer letter review for expedited processing',
      'Guidance on working legally while waiting for your permanent NI number',
      'HMRC correspondence tracking and query resolution advice'
    ]
  },
  {
    id: 'sim-setup',
    title: 'SIM & Mobile Setup',
    shortDesc: 'Get connected with the best mobile plans.',
    iconName: 'Smartphone',
    category: 'Connectivity',
    details: [
      'Free or discounted UK SIM card upon arrival (eSIM or physical)',
      'Comparison of top UK networks (EE, Vodafone, O2, Three, VOXI, Giffgaff)',
      'No-credit-check monthly rolling plans vs long-term contract advice',
      'Setup assistance for roaming, hotspot, and mobile banking verification',
      'Cheap international calling plans to stay in touch with family'
    ]
  },
  {
    id: 'transport',
    title: 'Transport & Travel Guidance',
    shortDesc: 'Learn buses, trains, underground and more.',
    iconName: 'Bus',
    category: 'Mobility',
    details: [
      'Oyster Card / Contactless payment system navigation in London',
      '16-25 / 26-30 Railcard setup for 1/3 discount on UK train travel',
      'Citymapper and TfL app navigation walk-through',
      'National Rail ticket booking tips and advance fare savings',
      'Local bus route maps, hopper fares, and night transport safety'
    ]
  },
  {
    id: 'banking',
    title: 'Bank Account & Everyday Setup',
    shortDesc: 'Get familiar with UK banking, shops, GP and essential services.',
    iconName: 'Building2',
    category: 'Daily Life',
    details: [
      'UK digital bank account setup (Monzo, Revolut, Starling) within 24 hours',
      'High-street bank appointments (Barclays, Lloyds, HSBC, NatWest)',
      'Proof of address letter preparation guidance',
      'NHS GP surgery registration and dentist enrolment help',
      'Grocery shopping hacks (Tesco, Sainsbury’s, Lidl, Aldi, Asian grocers)'
    ]
  },
  {
    id: 'orientation',
    title: 'Local Area Orientation',
    shortDesc: 'Discover your local area and essential places.',
    iconName: 'MapPin',
    category: 'Settling In',
    details: [
      'Guided walkthrough of your immediate neighbourhood and high street',
      'Identification of nearest supermarket, pharmacy, post office and GP',
      'Safe walking routes and public transit station access points',
      'Local community groups, student unions, and places of worship',
      'Emergency contacts, non-emergency 101/111, and safety awareness'
    ]
  }
];

export const PACKAGES: PackageItem[] = [
  {
    id: 'arrival-package',
    name: 'Arrival Package',
    subtitle: 'For people who mainly need help on arrival.',
    price: 'From £99',
    priceNumber: 99,
    themeColor: 'sky',
    features: [
      'Airport pickup',
      'Meet & greet',
      'Transport to accommodation',
      'Basic local orientation'
    ]
  },
  {
    id: 'settle-in-package',
    name: 'Settle-In Package',
    subtitle: 'For students, workers and newcomers.',
    price: 'From £199',
    priceNumber: 199,
    themeColor: 'emerald',
    popular: true,
    features: [
      'Airport pickup',
      'Accommodation search',
      'SIM/mobile guidance',
      'Transport guidance',
      'NI application guidance',
      'Local area orientation'
    ]
  },
  {
    id: 'job-start-package',
    name: 'Job Start Package',
    subtitle: 'For those ready to start looking for work.',
    price: 'From £149',
    priceNumber: 149,
    themeColor: 'indigo',
    features: [
      'Job search consultation',
      'CV guidance',
      'Application support',
      'Interview preparation',
      'Local job search guidance'
    ]
  },
  {
    id: 'complete-uk-package',
    name: 'Complete UK Start Package',
    subtitle: 'From airport to your first steps in the UK.',
    price: 'From £299',
    priceNumber: 299,
    themeColor: 'navy',
    popular: true,
    features: [
      'All services included',
      'Personalised support',
      'Flexible options',
      'Priority assistance'
    ]
  }
];

export const JOURNEY_STEPS: StepItem[] = [
  {
    step: 1,
    title: 'Tell Us About Your Arrival',
    description: 'Share your date, time and flight details & requirements.',
    iconName: 'Calendar',
    highlights: ['Online submission', 'Flight details', 'Personal needs']
  },
  {
    step: 2,
    title: 'Choose Your Services',
    description: 'Select what you need or a full package.',
    iconName: 'CheckSquare',
    highlights: ['A la carte or bundle', 'Transparent pricing', 'No hidden fees']
  },
  {
    step: 3,
    title: 'Plan Your Arrival',
    description: 'We will confirm details, driver and booking info.',
    iconName: 'ClipboardCheck',
    highlights: ['Assigned personal advisor', 'Driver contact details', 'Emergency line']
  },
  {
    step: 4,
    title: 'Arrive in the UK',
    description: 'Greeted at arrivals, luggage help & transportation.',
    iconName: 'PlaneTakeoff',
    highlights: ['Arrival hall welcome', 'Spacious vehicle', 'Direct transfer']
  },
  {
    step: 5,
    title: 'Start Settling In',
    description: 'We help with your accommodation & essential setup.',
    iconName: 'Key',
    highlights: ['Keys & check-in', 'UK SIM activated', 'Banking & GP guidance']
  },
  {
    step: 6,
    title: 'Start Your New Journey',
    description: 'Become confident and independent in your UK life.',
    iconName: 'Compass',
    highlights: ['Ongoing WhatsApp support', 'Local community insights', 'Thriving in the UK']
  }
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'ayesha',
    name: 'Ayesha',
    role: 'Student',
    rating: 5,
    quote: 'They made my arrival in the UK so easy. From airport pickup to accommodation, everything was well organised. I really appreciate their support!',
    verified: true,
    avatarBg: 'bg-amber-100 text-amber-800'
  },
  {
    id: 'rahman',
    name: 'Rahman',
    role: 'Worker',
    rating: 5,
    quote: 'Great service and very friendly team. They helped me with my job search and local area guidance. Highly recommended!',
    verified: true,
    avatarBg: 'bg-emerald-100 text-emerald-800'
  },
  {
    id: 'sultana',
    name: 'Sultana',
    role: 'Newcomer',
    rating: 5,
    quote: 'Professional, helpful and reliable. I felt confident throughout the process. They are truly travel friendly!',
    verified: true,
    avatarBg: 'bg-sky-100 text-sky-800'
  }
];

export const FAQS: FaqItem[] = [
  {
    id: 'faq-1',
    category: 'Arrival',
    question: 'Do you provide airport pickup?',
    answer: 'Yes! We monitor your incoming flight in real time and meet you inside the arrival terminal holding a visible greeting sign with your name. We assist with heavy luggage and transport you directly to your accommodation in London or other UK cities in clean, comfortable, insured vehicles.'
  },
  {
    id: 'faq-2',
    category: 'Career',
    question: 'Can you guarantee me a job?',
    answer: 'While no reputable agency can legally guarantee employment, our Job Start support equips you with industry-standard UK CV restructuring, guidance on right-to-work requirements, insider job portal techniques, and interview preparation to maximize your likelihood of securing employment swiftly.'
  },
  {
    id: 'faq-3',
    category: 'Housing',
    question: 'Can you arrange accommodation?',
    answer: 'We assist newcomers by finding vetted, safe, and budget-appropriate temporary and long-term accommodation. We help schedule viewings, perform landlord authenticity checks, review tenancy agreements, and guide you through council tax and utility registrations to protect you from rental scams.'
  },
  {
    id: 'faq-4',
    category: 'Legal',
    question: 'Can you help with my National Insurance application?',
    answer: 'Yes, we guide you through the official UK government (gov.uk) National Insurance number application step-by-step. We ensure you have all prerequisite documents ready (BRP or digital immigration status share code, passport, and address evidence) to prevent delays.'
  },
  {
    id: 'faq-5',
    category: 'Packages',
    question: 'Do I need to buy the full package?',
    answer: 'Not at all! You have total flexibility. You can choose single standalone services (like just airport pickup or just CV guidance), select one of our curated bundles (Arrival, Settle-In, or Job Start), or opt for the Complete UK Start Package for comprehensive end-to-end guidance.'
  }
];

export const UK_AIRPORTS = [
  'London Heathrow (LHR)',
  'London Gatwick (LGW)',
  'London Stansted (STN)',
  'London Luton (LTN)',
  'London City (LCY)',
  'Manchester Airport (MAN)',
  'Birmingham Airport (BHX)',
  'Edinburgh Airport (EDI)',
  'Other / Regional Airport'
];
